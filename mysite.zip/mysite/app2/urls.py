from django.urls import path
from . import views

urlpatterns = [
    path('index', views.index, name='app2_home'),
    path('about', views.about, name='app2_about'),
    path('contact', views.contact, name='app2_contact'),
]
